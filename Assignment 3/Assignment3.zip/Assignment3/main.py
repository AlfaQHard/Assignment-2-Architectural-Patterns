import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")

from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()

from MyApp.models import products

# adding to database
product = products(product_id='1011', product_name='Juice', product_price='3.50')
product.save()
