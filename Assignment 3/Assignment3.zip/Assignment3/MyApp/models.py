from django.db import models

# Database model
class products(models.Model):
    product_id = models.CharField(max_length=10)
    product_name = models.CharField(max_length=30)
    product_price = models.CharField(max_length=10)
