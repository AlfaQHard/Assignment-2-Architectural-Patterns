from django.conf.urls import url
import views


# url for the view to open the html
urlpatterns = [
    url('', views.prod, name='home')
]