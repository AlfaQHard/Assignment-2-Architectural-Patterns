import os

# Defines base dir for all relative imports for project, put file in root folder so base_dir
# points to root folder

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DEBUG = True
ALLOWED_HOSTS = ['*']
ROOT_URLCONF = 'urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,
    },
]

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'products',
        'USER': 'root',
        'PASSWORD': 'root',
        'HOST': 'localhost',
        'PORT': '3306',
        'OPTIONS': {
            'init_command': "SET sql_mode='STRICT_TRANS_TABLES'"
        }
    }
}

INSTALLED_APPS = (
    'MyApp',
)

SECRET_KEY = 'o8ew&njw$zds%so_uh5%leh#smz7-f!^keyh%pv!p04+9zr^%*'
