from django.shortcuts import render
from MyApp.models import products


# View to display cashregister and make the necessary updates
def prod(request):
    if request.GET.get('enter') == 'enter':
        product_id = request.GET.get('textbox')

        product = products.objects.filter(product_id=product_id).values_list()
        prod = list(product[0])
        prod.remove(prod[0])
        print(prod)
        context = {'products': prod}

        return render(request, 'Assignment3.html', context)
    return render(request, 'Assignment3.html')

